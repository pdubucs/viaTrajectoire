﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void connexionBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.connexionBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form10_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Connexion'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.connexionTableAdapter.Fill(this.structureBddDataSet.Connexion);

        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.connexionTableAdapter.FillBy(this.structureBddDataSet.Connexion, new System.Nullable<int>(((int)(System.Convert.ChangeType(infoIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
