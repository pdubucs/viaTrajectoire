﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void commissionBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.commissionBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Commission'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.commissionTableAdapter.Fill(this.structureBddDataSet.Commission);

        }

        private void idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.commissionTableAdapter.Id(this.structureBddDataSet.Commission, new System.Nullable<int>(((int)(System.Convert.ChangeType(structureIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
