﻿namespace viaTrajDb
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.structureBddDataSet = new viaTrajDb.structureBddDataSet();
            this.effectifBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.effectifTableAdapter = new viaTrajDb.structureBddDataSetTableAdapters.EffectifTableAdapter();
            this.tableAdapterManager = new viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager();
            this.effectifBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.effectifBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.effectifDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idToolStrip = new System.Windows.Forms.ToolStrip();
            this.structureIdToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.structureIdToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.idToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.effectifBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.effectifBindingNavigator)).BeginInit();
            this.effectifBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.effectifDataGridView)).BeginInit();
            this.idToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // structureBddDataSet
            // 
            this.structureBddDataSet.DataSetName = "structureBddDataSet";
            this.structureBddDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // effectifBindingSource
            // 
            this.effectifBindingSource.DataMember = "Effectif";
            this.effectifBindingSource.DataSource = this.structureBddDataSet;
            // 
            // effectifTableAdapter
            // 
            this.effectifTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CommissionTableAdapter = null;
            this.tableAdapterManager.ConnexionTableAdapter = null;
            this.tableAdapterManager.ConseilTableAdapter = null;
            this.tableAdapterManager.EffectifTableAdapter = this.effectifTableAdapter;
            this.tableAdapterManager.FusionTableAdapter = null;
            this.tableAdapterManager.GroupementTableAdapter = null;
            this.tableAdapterManager.Infrastructure_InformatiqueTableAdapter = null;
            this.tableAdapterManager.Logiciel_Dossier_AdminTableAdapter = null;
            this.tableAdapterManager.logiciel_Dossier_SoinsTableAdapter = null;
            this.tableAdapterManager.maintenanceTableAdapter = null;
            this.tableAdapterManager.Membre_CommisionTableAdapter = null;
            this.tableAdapterManager.MessagerieTableAdapter = null;
            this.tableAdapterManager.Module_AdminTableAdapter = null;
            this.tableAdapterManager.Module_SoinsTableAdapter = null;
            this.tableAdapterManager.SauvegardeTableAdapter = null;
            this.tableAdapterManager.SpecialiteTableAdapter = null;
            this.tableAdapterManager.StructureTableAdapter = null;
            this.tableAdapterManager.TelephonieTableAdapter = null;
            this.tableAdapterManager.telesanteTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // effectifBindingNavigator
            // 
            this.effectifBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.effectifBindingNavigator.BindingSource = this.effectifBindingSource;
            this.effectifBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.effectifBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.effectifBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.effectifBindingNavigatorSaveItem});
            this.effectifBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.effectifBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.effectifBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.effectifBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.effectifBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.effectifBindingNavigator.Name = "effectifBindingNavigator";
            this.effectifBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.effectifBindingNavigator.Size = new System.Drawing.Size(802, 25);
            this.effectifBindingNavigator.TabIndex = 0;
            this.effectifBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // effectifBindingNavigatorSaveItem
            // 
            this.effectifBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.effectifBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("effectifBindingNavigatorSaveItem.Image")));
            this.effectifBindingNavigatorSaveItem.Name = "effectifBindingNavigatorSaveItem";
            this.effectifBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.effectifBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.effectifBindingNavigatorSaveItem.Click += new System.EventHandler(this.effectifBindingNavigatorSaveItem_Click);
            // 
            // effectifDataGridView
            // 
            this.effectifDataGridView.AutoGenerateColumns = false;
            this.effectifDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.effectifDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10});
            this.effectifDataGridView.DataSource = this.effectifBindingSource;
            this.effectifDataGridView.Location = new System.Drawing.Point(0, 59);
            this.effectifDataGridView.Name = "effectifDataGridView";
            this.effectifDataGridView.Size = new System.Drawing.Size(790, 253);
            this.effectifDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Médecins";
            this.dataGridViewTextBoxColumn2.HeaderText = "Médecins";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Médecin Coordinateur";
            this.dataGridViewTextBoxColumn3.HeaderText = "Médecin Coordinateur";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Pharmaciens";
            this.dataGridViewTextBoxColumn4.HeaderText = "Pharmaciens";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Personnels soignants";
            this.dataGridViewTextBoxColumn5.HeaderText = "Personnels soignants";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Personnels paramédicaux";
            this.dataGridViewTextBoxColumn6.HeaderText = "Personnels paramédicaux";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Personnels hôteliers";
            this.dataGridViewTextBoxColumn7.HeaderText = "Personnels hôteliers";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Personnels administratifs";
            this.dataGridViewTextBoxColumn8.HeaderText = "Personnels administratifs";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Personnels éducatif, pédagogique, social et d?animation";
            this.dataGridViewTextBoxColumn9.HeaderText = "Personnels éducatif, pédagogique, social et d?animation";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "StructureId";
            this.dataGridViewTextBoxColumn10.HeaderText = "StructureId";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // idToolStrip
            // 
            this.idToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.structureIdToolStripLabel,
            this.structureIdToolStripTextBox,
            this.idToolStripButton});
            this.idToolStrip.Location = new System.Drawing.Point(0, 25);
            this.idToolStrip.Name = "idToolStrip";
            this.idToolStrip.Size = new System.Drawing.Size(802, 25);
            this.idToolStrip.TabIndex = 2;
            this.idToolStrip.Text = "idToolStrip";
            // 
            // structureIdToolStripLabel
            // 
            this.structureIdToolStripLabel.Name = "structureIdToolStripLabel";
            this.structureIdToolStripLabel.Size = new System.Drawing.Size(21, 22);
            this.structureIdToolStripLabel.Text = "ID:";
            // 
            // structureIdToolStripTextBox
            // 
            this.structureIdToolStripTextBox.Name = "structureIdToolStripTextBox";
            this.structureIdToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // idToolStripButton
            // 
            this.idToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.idToolStripButton.Name = "idToolStripButton";
            this.idToolStripButton.Size = new System.Drawing.Size(70, 22);
            this.idToolStripButton.Text = "Rechercher";
            this.idToolStripButton.Click += new System.EventHandler(this.idToolStripButton_Click);
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 491);
            this.Controls.Add(this.idToolStrip);
            this.Controls.Add(this.effectifDataGridView);
            this.Controls.Add(this.effectifBindingNavigator);
            this.Name = "Form7";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.effectifBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.effectifBindingNavigator)).EndInit();
            this.effectifBindingNavigator.ResumeLayout(false);
            this.effectifBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.effectifDataGridView)).EndInit();
            this.idToolStrip.ResumeLayout(false);
            this.idToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private structureBddDataSet structureBddDataSet;
        private System.Windows.Forms.BindingSource effectifBindingSource;
        private structureBddDataSetTableAdapters.EffectifTableAdapter effectifTableAdapter;
        private structureBddDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator effectifBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton effectifBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView effectifDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.ToolStrip idToolStrip;
        private System.Windows.Forms.ToolStripLabel structureIdToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox structureIdToolStripTextBox;
        private System.Windows.Forms.ToolStripButton idToolStripButton;
    }
}