﻿namespace viaTrajDb
{
    partial class Form10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form10));
            this.structureBddDataSet = new viaTrajDb.structureBddDataSet();
            this.connexionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.connexionTableAdapter = new viaTrajDb.structureBddDataSetTableAdapters.ConnexionTableAdapter();
            this.tableAdapterManager = new viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager();
            this.connexionBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.connexionBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.connexionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.infoIdToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.infoIdToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.connexionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.connexionBindingNavigator)).BeginInit();
            this.connexionBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.connexionDataGridView)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // structureBddDataSet
            // 
            this.structureBddDataSet.DataSetName = "structureBddDataSet";
            this.structureBddDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // connexionBindingSource
            // 
            this.connexionBindingSource.DataMember = "Connexion";
            this.connexionBindingSource.DataSource = this.structureBddDataSet;
            // 
            // connexionTableAdapter
            // 
            this.connexionTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CommissionTableAdapter = null;
            this.tableAdapterManager.ConnexionTableAdapter = this.connexionTableAdapter;
            this.tableAdapterManager.ConseilTableAdapter = null;
            this.tableAdapterManager.EffectifTableAdapter = null;
            this.tableAdapterManager.FusionTableAdapter = null;
            this.tableAdapterManager.GroupementTableAdapter = null;
            this.tableAdapterManager.Infrastructure_InformatiqueTableAdapter = null;
            this.tableAdapterManager.Logiciel_Dossier_AdminTableAdapter = null;
            this.tableAdapterManager.logiciel_Dossier_SoinsTableAdapter = null;
            this.tableAdapterManager.maintenanceTableAdapter = null;
            this.tableAdapterManager.Membre_CommisionTableAdapter = null;
            this.tableAdapterManager.MessagerieTableAdapter = null;
            this.tableAdapterManager.Module_AdminTableAdapter = null;
            this.tableAdapterManager.Module_SoinsTableAdapter = null;
            this.tableAdapterManager.SauvegardeTableAdapter = null;
            this.tableAdapterManager.SpecialiteTableAdapter = null;
            this.tableAdapterManager.StructureTableAdapter = null;
            this.tableAdapterManager.TelephonieTableAdapter = null;
            this.tableAdapterManager.telesanteTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // connexionBindingNavigator
            // 
            this.connexionBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.connexionBindingNavigator.BindingSource = this.connexionBindingSource;
            this.connexionBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.connexionBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.connexionBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.connexionBindingNavigatorSaveItem});
            this.connexionBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.connexionBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.connexionBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.connexionBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.connexionBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.connexionBindingNavigator.Name = "connexionBindingNavigator";
            this.connexionBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.connexionBindingNavigator.Size = new System.Drawing.Size(803, 25);
            this.connexionBindingNavigator.TabIndex = 0;
            this.connexionBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // connexionBindingNavigatorSaveItem
            // 
            this.connexionBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.connexionBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("connexionBindingNavigatorSaveItem.Image")));
            this.connexionBindingNavigatorSaveItem.Name = "connexionBindingNavigatorSaveItem";
            this.connexionBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.connexionBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.connexionBindingNavigatorSaveItem.Click += new System.EventHandler(this.connexionBindingNavigatorSaveItem_Click);
            // 
            // connexionDataGridView
            // 
            this.connexionDataGridView.AutoGenerateColumns = false;
            this.connexionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.connexionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.connexionDataGridView.DataSource = this.connexionBindingSource;
            this.connexionDataGridView.Location = new System.Drawing.Point(21, 73);
            this.connexionDataGridView.Name = "connexionDataGridView";
            this.connexionDataGridView.Size = new System.Drawing.Size(743, 367);
            this.connexionDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "connexionId";
            this.dataGridViewTextBoxColumn1.HeaderText = "connexionId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nomModuleSoins";
            this.dataGridViewTextBoxColumn2.HeaderText = "nomModuleSoins";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "typeConnexion";
            this.dataGridViewTextBoxColumn3.HeaderText = "typeConnexion";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "debit";
            this.dataGridViewTextBoxColumn4.HeaderText = "debit";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "FAI";
            this.dataGridViewTextBoxColumn5.HeaderText = "FAI";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "WIFI";
            this.dataGridViewTextBoxColumn6.HeaderText = "WIFI";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "infoId";
            this.dataGridViewTextBoxColumn7.HeaderText = "infoId";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoIdToolStripLabel,
            this.infoIdToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 25);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(803, 25);
            this.fillByToolStrip.TabIndex = 2;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // infoIdToolStripLabel
            // 
            this.infoIdToolStripLabel.Name = "infoIdToolStripLabel";
            this.infoIdToolStripLabel.Size = new System.Drawing.Size(18, 22);
            this.infoIdToolStripLabel.Text = "ID";
            // 
            // infoIdToolStripTextBox
            // 
            this.infoIdToolStripTextBox.Name = "infoIdToolStripTextBox";
            this.infoIdToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(70, 22);
            this.fillByToolStripButton.Text = "Rechercher";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // Form10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 479);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.connexionDataGridView);
            this.Controls.Add(this.connexionBindingNavigator);
            this.Name = "Form10";
            this.Text = "Form10";
            this.Load += new System.EventHandler(this.Form10_Load);
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.connexionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.connexionBindingNavigator)).EndInit();
            this.connexionBindingNavigator.ResumeLayout(false);
            this.connexionBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.connexionDataGridView)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private structureBddDataSet structureBddDataSet;
        private System.Windows.Forms.BindingSource connexionBindingSource;
        private structureBddDataSetTableAdapters.ConnexionTableAdapter connexionTableAdapter;
        private structureBddDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator connexionBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton connexionBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView connexionDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel infoIdToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox infoIdToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}