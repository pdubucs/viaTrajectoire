﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void infrastructure_InformatiqueBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.infrastructure_InformatiqueBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Infrastructure_Informatique'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.infrastructure_InformatiqueTableAdapter.Fill(this.structureBddDataSet.Infrastructure_Informatique);

        }

        private void idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.infrastructure_InformatiqueTableAdapter.Id(this.structureBddDataSet.Infrastructure_Informatique, new System.Nullable<int>(((int)(System.Convert.ChangeType(structureIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
