﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void telesanteBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.telesanteBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.telesante'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.telesanteTableAdapter.Fill(this.structureBddDataSet.telesante);

        }

        private void iDToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.telesanteTableAdapter.ID(this.structureBddDataSet.telesante, new System.Nullable<int>(((int)(System.Convert.ChangeType(structureIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
