﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void groupementBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.groupementBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form8_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Groupement'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.groupementTableAdapter.Fill(this.structureBddDataSet.Groupement);

        }

        private void iDToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.groupementTableAdapter.ID(this.structureBddDataSet.Groupement, new System.Nullable<int>(((int)(System.Convert.ChangeType(structureIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
