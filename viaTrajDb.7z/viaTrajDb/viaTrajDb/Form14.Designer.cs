﻿namespace viaTrajDb
{
    partial class Form14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form14));
            this.structureBddDataSet = new viaTrajDb.structureBddDataSet();
            this.telephonieBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.telephonieTableAdapter = new viaTrajDb.structureBddDataSetTableAdapters.TelephonieTableAdapter();
            this.tableAdapterManager = new viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager();
            this.telephonieBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.telephonieBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.telephonieDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idToolStrip = new System.Windows.Forms.ToolStrip();
            this.infoIdToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.infoIdToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.idToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.telephonieBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.telephonieBindingNavigator)).BeginInit();
            this.telephonieBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.telephonieDataGridView)).BeginInit();
            this.idToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // structureBddDataSet
            // 
            this.structureBddDataSet.DataSetName = "structureBddDataSet";
            this.structureBddDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // telephonieBindingSource
            // 
            this.telephonieBindingSource.DataMember = "Telephonie";
            this.telephonieBindingSource.DataSource = this.structureBddDataSet;
            // 
            // telephonieTableAdapter
            // 
            this.telephonieTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CommissionTableAdapter = null;
            this.tableAdapterManager.ConnexionTableAdapter = null;
            this.tableAdapterManager.ConseilTableAdapter = null;
            this.tableAdapterManager.EffectifTableAdapter = null;
            this.tableAdapterManager.FusionTableAdapter = null;
            this.tableAdapterManager.GroupementTableAdapter = null;
            this.tableAdapterManager.Infrastructure_InformatiqueTableAdapter = null;
            this.tableAdapterManager.Logiciel_Dossier_AdminTableAdapter = null;
            this.tableAdapterManager.logiciel_Dossier_SoinsTableAdapter = null;
            this.tableAdapterManager.maintenanceTableAdapter = null;
            this.tableAdapterManager.Membre_CommisionTableAdapter = null;
            this.tableAdapterManager.MessagerieTableAdapter = null;
            this.tableAdapterManager.Module_AdminTableAdapter = null;
            this.tableAdapterManager.Module_SoinsTableAdapter = null;
            this.tableAdapterManager.SauvegardeTableAdapter = null;
            this.tableAdapterManager.SpecialiteTableAdapter = null;
            this.tableAdapterManager.StructureTableAdapter = null;
            this.tableAdapterManager.TelephonieTableAdapter = this.telephonieTableAdapter;
            this.tableAdapterManager.telesanteTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // telephonieBindingNavigator
            // 
            this.telephonieBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.telephonieBindingNavigator.BindingSource = this.telephonieBindingSource;
            this.telephonieBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.telephonieBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.telephonieBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.telephonieBindingNavigatorSaveItem});
            this.telephonieBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.telephonieBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.telephonieBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.telephonieBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.telephonieBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.telephonieBindingNavigator.Name = "telephonieBindingNavigator";
            this.telephonieBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.telephonieBindingNavigator.Size = new System.Drawing.Size(802, 25);
            this.telephonieBindingNavigator.TabIndex = 0;
            this.telephonieBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // telephonieBindingNavigatorSaveItem
            // 
            this.telephonieBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.telephonieBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("telephonieBindingNavigatorSaveItem.Image")));
            this.telephonieBindingNavigatorSaveItem.Name = "telephonieBindingNavigatorSaveItem";
            this.telephonieBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.telephonieBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.telephonieBindingNavigatorSaveItem.Click += new System.EventHandler(this.telephonieBindingNavigatorSaveItem_Click);
            // 
            // telephonieDataGridView
            // 
            this.telephonieDataGridView.AutoGenerateColumns = false;
            this.telephonieDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.telephonieDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.telephonieDataGridView.DataSource = this.telephonieBindingSource;
            this.telephonieDataGridView.Location = new System.Drawing.Point(12, 78);
            this.telephonieDataGridView.Name = "telephonieDataGridView";
            this.telephonieDataGridView.Size = new System.Drawing.Size(778, 225);
            this.telephonieDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "telephonieId";
            this.dataGridViewTextBoxColumn1.HeaderText = "telephonieId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nombrePosteInfo";
            this.dataGridViewTextBoxColumn2.HeaderText = "nombrePosteInfo";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "telephoneResident";
            this.dataGridViewTextBoxColumn3.HeaderText = "telephoneResident";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "prise";
            this.dataGridViewTextBoxColumn4.HeaderText = "prise";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "type";
            this.dataGridViewTextBoxColumn5.HeaderText = "type";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "nombrePosteFixe";
            this.dataGridViewTextBoxColumn6.HeaderText = "nombrePosteFixe";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "nombrePosteSansFil";
            this.dataGridViewTextBoxColumn7.HeaderText = "nombrePosteSansFil";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "appelMalade";
            this.dataGridViewTextBoxColumn8.HeaderText = "appelMalade";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "appelMaladeType";
            this.dataGridViewTextBoxColumn9.HeaderText = "appelMaladeType";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "autocommutateur";
            this.dataGridViewTextBoxColumn10.HeaderText = "autocommutateur";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "infoId";
            this.dataGridViewTextBoxColumn11.HeaderText = "infoId";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // idToolStrip
            // 
            this.idToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.infoIdToolStripLabel,
            this.infoIdToolStripTextBox,
            this.idToolStripButton});
            this.idToolStrip.Location = new System.Drawing.Point(0, 25);
            this.idToolStrip.Name = "idToolStrip";
            this.idToolStrip.Size = new System.Drawing.Size(802, 25);
            this.idToolStrip.TabIndex = 2;
            this.idToolStrip.Text = "idToolStrip";
            // 
            // infoIdToolStripLabel
            // 
            this.infoIdToolStripLabel.Name = "infoIdToolStripLabel";
            this.infoIdToolStripLabel.Size = new System.Drawing.Size(21, 22);
            this.infoIdToolStripLabel.Text = "ID:";
            this.infoIdToolStripLabel.Click += new System.EventHandler(this.infoIdToolStripLabel_Click);
            // 
            // infoIdToolStripTextBox
            // 
            this.infoIdToolStripTextBox.Name = "infoIdToolStripTextBox";
            this.infoIdToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // idToolStripButton
            // 
            this.idToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.idToolStripButton.Name = "idToolStripButton";
            this.idToolStripButton.Size = new System.Drawing.Size(70, 22);
            this.idToolStripButton.Text = "Rechercher";
            this.idToolStripButton.Click += new System.EventHandler(this.idToolStripButton_Click);
            // 
            // Form14
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 444);
            this.Controls.Add(this.idToolStrip);
            this.Controls.Add(this.telephonieDataGridView);
            this.Controls.Add(this.telephonieBindingNavigator);
            this.Name = "Form14";
            this.Text = "Form14";
            this.Load += new System.EventHandler(this.Form14_Load);
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.telephonieBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.telephonieBindingNavigator)).EndInit();
            this.telephonieBindingNavigator.ResumeLayout(false);
            this.telephonieBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.telephonieDataGridView)).EndInit();
            this.idToolStrip.ResumeLayout(false);
            this.idToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private structureBddDataSet structureBddDataSet;
        private System.Windows.Forms.BindingSource telephonieBindingSource;
        private structureBddDataSetTableAdapters.TelephonieTableAdapter telephonieTableAdapter;
        private structureBddDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator telephonieBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton telephonieBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView telephonieDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.ToolStrip idToolStrip;
        private System.Windows.Forms.ToolStripLabel infoIdToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox infoIdToolStripTextBox;
        private System.Windows.Forms.ToolStripButton idToolStripButton;
    }
}