﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form11 : Form
    {
        public Form11()
        {
            InitializeComponent();
        }

        private void conseilBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.conseilBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form11_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Conseil'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.conseilTableAdapter.Fill(this.structureBddDataSet.Conseil);

        }

        private void idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.conseilTableAdapter.id(this.structureBddDataSet.Conseil, new System.Nullable<int>(((int)(System.Convert.ChangeType(infoIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
