﻿namespace viaTrajDb
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.structureBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.structureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.structureBddDataSet = new viaTrajDb.structureBddDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.structureBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.structureDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.structureTableAdapter = new viaTrajDb.structureBddDataSetTableAdapters.StructureTableAdapter();
            this.tableAdapterManager = new viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager();
            this.nom1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.nomToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.nomToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.nom1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.structureBindingNavigator)).BeginInit();
            this.structureBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.structureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.structureDataGridView)).BeginInit();
            this.nom1ToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // structureBindingNavigator
            // 
            this.structureBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.structureBindingNavigator.BindingSource = this.structureBindingSource;
            this.structureBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.structureBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.structureBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.structureBindingNavigatorSaveItem});
            this.structureBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.structureBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.structureBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.structureBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.structureBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.structureBindingNavigator.Name = "structureBindingNavigator";
            this.structureBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.structureBindingNavigator.Size = new System.Drawing.Size(808, 25);
            this.structureBindingNavigator.TabIndex = 0;
            this.structureBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // structureBindingSource
            // 
            this.structureBindingSource.DataMember = "Structure";
            this.structureBindingSource.DataSource = this.structureBddDataSet;
            // 
            // structureBddDataSet
            // 
            this.structureBddDataSet.DataSetName = "structureBddDataSet";
            this.structureBddDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // structureBindingNavigatorSaveItem
            // 
            this.structureBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.structureBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("structureBindingNavigatorSaveItem.Image")));
            this.structureBindingNavigatorSaveItem.Name = "structureBindingNavigatorSaveItem";
            this.structureBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.structureBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.structureBindingNavigatorSaveItem.Click += new System.EventHandler(this.structureBindingNavigatorSaveItem_Click);
            // 
            // structureDataGridView
            // 
            this.structureDataGridView.AutoGenerateColumns = false;
            this.structureDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.structureDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewCheckBoxColumn1,
            this.dataGridViewCheckBoxColumn2,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18});
            this.structureDataGridView.DataSource = this.structureBindingSource;
            this.structureDataGridView.Location = new System.Drawing.Point(12, 64);
            this.structureDataGridView.Name = "structureDataGridView";
            this.structureDataGridView.Size = new System.Drawing.Size(784, 281);
            this.structureDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "structureId";
            this.dataGridViewTextBoxColumn1.HeaderText = "structureId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nom";
            this.dataGridViewTextBoxColumn2.HeaderText = "nom";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "departement";
            this.dataGridViewTextBoxColumn3.HeaderText = "departement";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "capacite";
            this.dataGridViewTextBoxColumn4.HeaderText = "capacite";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "typeProfil";
            this.dataGridViewTextBoxColumn5.HeaderText = "typeProfil";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "typeHebergement";
            this.dataGridViewTextBoxColumn6.HeaderText = "typeHebergement";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "traitementAilzeimer";
            this.dataGridViewTextBoxColumn7.HeaderText = "traitementAilzeimer";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "phv";
            this.dataGridViewTextBoxColumn8.HeaderText = "phv";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "anneeBatiment";
            this.dataGridViewTextBoxColumn9.HeaderText = "anneeBatiment";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "pathos";
            this.dataGridViewTextBoxColumn10.HeaderText = "pathos";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "gmp";
            this.dataGridViewTextBoxColumn11.HeaderText = "gmp";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "zone";
            this.dataGridViewTextBoxColumn12.HeaderText = "zone";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "tarifJournalier";
            this.dataGridViewTextBoxColumn13.HeaderText = "tarifJournalier";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "serviceUrgence";
            this.dataGridViewTextBoxColumn14.HeaderText = "serviceUrgence";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.DataPropertyName = "dotationGlobale";
            this.dataGridViewCheckBoxColumn1.HeaderText = "dotationGlobale";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "dotationPartiel";
            this.dataGridViewCheckBoxColumn2.HeaderText = "dotationPartiel";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "sosMedecin";
            this.dataGridViewTextBoxColumn15.HeaderText = "sosMedecin";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "contact";
            this.dataGridViewTextBoxColumn16.HeaderText = "contact";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "mailContact";
            this.dataGridViewTextBoxColumn17.HeaderText = "mailContact";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "village";
            this.dataGridViewTextBoxColumn18.HeaderText = "village";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // structureTableAdapter
            // 
            this.structureTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CommissionTableAdapter = null;
            this.tableAdapterManager.ConnexionTableAdapter = null;
            this.tableAdapterManager.ConseilTableAdapter = null;
            this.tableAdapterManager.EffectifTableAdapter = null;
            this.tableAdapterManager.FusionTableAdapter = null;
            this.tableAdapterManager.GroupementTableAdapter = null;
            this.tableAdapterManager.Infrastructure_InformatiqueTableAdapter = null;
            this.tableAdapterManager.Logiciel_Dossier_AdminTableAdapter = null;
            this.tableAdapterManager.logiciel_Dossier_SoinsTableAdapter = null;
            this.tableAdapterManager.maintenanceTableAdapter = null;
            this.tableAdapterManager.Membre_CommisionTableAdapter = null;
            this.tableAdapterManager.MessagerieTableAdapter = null;
            this.tableAdapterManager.Module_AdminTableAdapter = null;
            this.tableAdapterManager.Module_SoinsTableAdapter = null;
            this.tableAdapterManager.SauvegardeTableAdapter = null;
            this.tableAdapterManager.SpecialiteTableAdapter = null;
            this.tableAdapterManager.StructureTableAdapter = this.structureTableAdapter;
            this.tableAdapterManager.TelephonieTableAdapter = null;
            this.tableAdapterManager.telesanteTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nom1ToolStrip
            // 
            this.nom1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nomToolStripLabel,
            this.nomToolStripTextBox,
            this.nom1ToolStripButton});
            this.nom1ToolStrip.Location = new System.Drawing.Point(0, 25);
            this.nom1ToolStrip.Name = "nom1ToolStrip";
            this.nom1ToolStrip.Size = new System.Drawing.Size(808, 25);
            this.nom1ToolStrip.TabIndex = 2;
            this.nom1ToolStrip.Text = "nom1ToolStrip";
            // 
            // nomToolStripLabel
            // 
            this.nomToolStripLabel.Name = "nomToolStripLabel";
            this.nomToolStripLabel.Size = new System.Drawing.Size(35, 22);
            this.nomToolStripLabel.Text = "nom:";
            // 
            // nomToolStripTextBox
            // 
            this.nomToolStripTextBox.Name = "nomToolStripTextBox";
            this.nomToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // nom1ToolStripButton
            // 
            this.nom1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.nom1ToolStripButton.Name = "nom1ToolStripButton";
            this.nom1ToolStripButton.Size = new System.Drawing.Size(70, 22);
            this.nom1ToolStripButton.Text = "Rechercher";
            this.nom1ToolStripButton.Click += new System.EventHandler(this.nom1ToolStripButton_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 448);
            this.Controls.Add(this.nom1ToolStrip);
            this.Controls.Add(this.structureDataGridView);
            this.Controls.Add(this.structureBindingNavigator);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.structureBindingNavigator)).EndInit();
            this.structureBindingNavigator.ResumeLayout(false);
            this.structureBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.structureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.structureDataGridView)).EndInit();
            this.nom1ToolStrip.ResumeLayout(false);
            this.nom1ToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private structureBddDataSet structureBddDataSet;
        private System.Windows.Forms.BindingSource structureBindingSource;
        private structureBddDataSetTableAdapters.StructureTableAdapter structureTableAdapter;
        private structureBddDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator structureBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton structureBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView structureDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.ToolStrip nom1ToolStrip;
        private System.Windows.Forms.ToolStripLabel nomToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox nomToolStripTextBox;
        private System.Windows.Forms.ToolStripButton nom1ToolStripButton;
    }
}