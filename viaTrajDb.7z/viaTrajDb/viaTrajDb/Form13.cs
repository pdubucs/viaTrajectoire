﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        private void sauvegardeBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.sauvegardeBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form13_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Sauvegarde'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.sauvegardeTableAdapter.Fill(this.structureBddDataSet.Sauvegarde);

        }

        private void idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.sauvegardeTableAdapter.id(this.structureBddDataSet.Sauvegarde, new System.Nullable<int>(((int)(System.Convert.ChangeType(infoIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
