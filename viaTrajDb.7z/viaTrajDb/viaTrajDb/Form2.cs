﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void structureBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.structureBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Structure'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.structureTableAdapter.Fill(this.structureBddDataSet.Structure);

        }

      

        private void nom1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.structureTableAdapter.nom1(this.structureBddDataSet.Structure, nomToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
