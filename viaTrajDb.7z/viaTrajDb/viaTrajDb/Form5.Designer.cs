﻿namespace viaTrajDb
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.structureBddDataSet = new viaTrajDb.structureBddDataSet();
            this.logiciel_Dossier_SoinsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.logiciel_Dossier_SoinsTableAdapter = new viaTrajDb.structureBddDataSetTableAdapters.logiciel_Dossier_SoinsTableAdapter();
            this.tableAdapterManager = new viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager();
            this.logiciel_Dossier_SoinsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.logiciel_Dossier_SoinsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idToolStrip = new System.Windows.Forms.ToolStrip();
            this.structureIdToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.structureIdToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.idToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logiciel_Dossier_SoinsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logiciel_Dossier_SoinsBindingNavigator)).BeginInit();
            this.logiciel_Dossier_SoinsBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logiciel_Dossier_SoinsDataGridView)).BeginInit();
            this.idToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // structureBddDataSet
            // 
            this.structureBddDataSet.DataSetName = "structureBddDataSet";
            this.structureBddDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // logiciel_Dossier_SoinsBindingSource
            // 
            this.logiciel_Dossier_SoinsBindingSource.DataMember = "logiciel Dossier Soins";
            this.logiciel_Dossier_SoinsBindingSource.DataSource = this.structureBddDataSet;
            // 
            // logiciel_Dossier_SoinsTableAdapter
            // 
            this.logiciel_Dossier_SoinsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CommissionTableAdapter = null;
            this.tableAdapterManager.ConnexionTableAdapter = null;
            this.tableAdapterManager.ConseilTableAdapter = null;
            this.tableAdapterManager.EffectifTableAdapter = null;
            this.tableAdapterManager.FusionTableAdapter = null;
            this.tableAdapterManager.GroupementTableAdapter = null;
            this.tableAdapterManager.Infrastructure_InformatiqueTableAdapter = null;
            this.tableAdapterManager.Logiciel_Dossier_AdminTableAdapter = null;
            this.tableAdapterManager.logiciel_Dossier_SoinsTableAdapter = this.logiciel_Dossier_SoinsTableAdapter;
            this.tableAdapterManager.maintenanceTableAdapter = null;
            this.tableAdapterManager.Membre_CommisionTableAdapter = null;
            this.tableAdapterManager.MessagerieTableAdapter = null;
            this.tableAdapterManager.Module_AdminTableAdapter = null;
            this.tableAdapterManager.Module_SoinsTableAdapter = null;
            this.tableAdapterManager.SauvegardeTableAdapter = null;
            this.tableAdapterManager.SpecialiteTableAdapter = null;
            this.tableAdapterManager.StructureTableAdapter = null;
            this.tableAdapterManager.TelephonieTableAdapter = null;
            this.tableAdapterManager.telesanteTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = viaTrajDb.structureBddDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // logiciel_Dossier_SoinsBindingNavigator
            // 
            this.logiciel_Dossier_SoinsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.logiciel_Dossier_SoinsBindingNavigator.BindingSource = this.logiciel_Dossier_SoinsBindingSource;
            this.logiciel_Dossier_SoinsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.logiciel_Dossier_SoinsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.logiciel_Dossier_SoinsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem});
            this.logiciel_Dossier_SoinsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.logiciel_Dossier_SoinsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.logiciel_Dossier_SoinsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.logiciel_Dossier_SoinsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.logiciel_Dossier_SoinsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.logiciel_Dossier_SoinsBindingNavigator.Name = "logiciel_Dossier_SoinsBindingNavigator";
            this.logiciel_Dossier_SoinsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.logiciel_Dossier_SoinsBindingNavigator.Size = new System.Drawing.Size(515, 25);
            this.logiciel_Dossier_SoinsBindingNavigator.TabIndex = 0;
            this.logiciel_Dossier_SoinsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Ajouter nouveau";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(37, 22);
            this.bindingNavigatorCountItem.Text = "de {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Nombre total d\'éléments";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Supprimer";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Placer en premier";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Déplacer vers le haut";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Position actuelle";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Déplacer vers le bas";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Placer en dernier";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // logiciel_Dossier_SoinsBindingNavigatorSaveItem
            // 
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("logiciel_Dossier_SoinsBindingNavigatorSaveItem.Image")));
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem.Name = "logiciel_Dossier_SoinsBindingNavigatorSaveItem";
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem.Text = "Enregistrer les données";
            this.logiciel_Dossier_SoinsBindingNavigatorSaveItem.Click += new System.EventHandler(this.logiciel_Dossier_SoinsBindingNavigatorSaveItem_Click);
            // 
            // logiciel_Dossier_SoinsDataGridView
            // 
            this.logiciel_Dossier_SoinsDataGridView.AutoGenerateColumns = false;
            this.logiciel_Dossier_SoinsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.logiciel_Dossier_SoinsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.logiciel_Dossier_SoinsDataGridView.DataSource = this.logiciel_Dossier_SoinsBindingSource;
            this.logiciel_Dossier_SoinsDataGridView.Location = new System.Drawing.Point(12, 85);
            this.logiciel_Dossier_SoinsDataGridView.Name = "logiciel_Dossier_SoinsDataGridView";
            this.logiciel_Dossier_SoinsDataGridView.Size = new System.Drawing.Size(300, 220);
            this.logiciel_Dossier_SoinsDataGridView.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "soinsId";
            this.dataGridViewTextBoxColumn1.HeaderText = "soinsId";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nomLogicielSoins";
            this.dataGridViewTextBoxColumn2.HeaderText = "nomLogicielSoins";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "structureId";
            this.dataGridViewTextBoxColumn3.HeaderText = "structureId";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // idToolStrip
            // 
            this.idToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.structureIdToolStripLabel,
            this.structureIdToolStripTextBox,
            this.idToolStripButton});
            this.idToolStrip.Location = new System.Drawing.Point(0, 25);
            this.idToolStrip.Name = "idToolStrip";
            this.idToolStrip.Size = new System.Drawing.Size(515, 25);
            this.idToolStrip.TabIndex = 2;
            this.idToolStrip.Text = "idToolStrip";
            // 
            // structureIdToolStripLabel
            // 
            this.structureIdToolStripLabel.Name = "structureIdToolStripLabel";
            this.structureIdToolStripLabel.Size = new System.Drawing.Size(21, 22);
            this.structureIdToolStripLabel.Text = "ID:";
            // 
            // structureIdToolStripTextBox
            // 
            this.structureIdToolStripTextBox.Name = "structureIdToolStripTextBox";
            this.structureIdToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // idToolStripButton
            // 
            this.idToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.idToolStripButton.Name = "idToolStripButton";
            this.idToolStripButton.Size = new System.Drawing.Size(70, 22);
            this.idToolStripButton.Text = "Rechercher";
            this.idToolStripButton.Click += new System.EventHandler(this.idToolStripButton_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(515, 409);
            this.Controls.Add(this.idToolStrip);
            this.Controls.Add(this.logiciel_Dossier_SoinsDataGridView);
            this.Controls.Add(this.logiciel_Dossier_SoinsBindingNavigator);
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            ((System.ComponentModel.ISupportInitialize)(this.structureBddDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logiciel_Dossier_SoinsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logiciel_Dossier_SoinsBindingNavigator)).EndInit();
            this.logiciel_Dossier_SoinsBindingNavigator.ResumeLayout(false);
            this.logiciel_Dossier_SoinsBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.logiciel_Dossier_SoinsDataGridView)).EndInit();
            this.idToolStrip.ResumeLayout(false);
            this.idToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private structureBddDataSet structureBddDataSet;
        private System.Windows.Forms.BindingSource logiciel_Dossier_SoinsBindingSource;
        private structureBddDataSetTableAdapters.logiciel_Dossier_SoinsTableAdapter logiciel_Dossier_SoinsTableAdapter;
        private structureBddDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator logiciel_Dossier_SoinsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton logiciel_Dossier_SoinsBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView logiciel_Dossier_SoinsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.ToolStrip idToolStrip;
        private System.Windows.Forms.ToolStripLabel structureIdToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox structureIdToolStripTextBox;
        private System.Windows.Forms.ToolStripButton idToolStripButton;
    }
}