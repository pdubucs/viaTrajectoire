﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void telephonieBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.telephonieBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form14_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Telephonie'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.telephonieTableAdapter.Fill(this.structureBddDataSet.Telephonie);

        }

        private void idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.telephonieTableAdapter.id(this.structureBddDataSet.Telephonie, new System.Nullable<int>(((int)(System.Convert.ChangeType(infoIdToolStripTextBox.Text, typeof(int))))));
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void infoIdToolStripLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
