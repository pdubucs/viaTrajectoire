﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viaTrajDb
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void effectifBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.effectifBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.structureBddDataSet);

        }

        private void Form7_Load(object sender, EventArgs e)
        {
            // TODO: cette ligne de code charge les données dans la table 'structureBddDataSet.Effectif'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
            this.effectifTableAdapter.Fill(this.structureBddDataSet.Effectif);

        }

        private void idToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.effectifTableAdapter.id(this.structureBddDataSet.Effectif, structureIdToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
